SELECT * 
FROM clientes
LIMIT 10;

SELECT 'Exemplo';