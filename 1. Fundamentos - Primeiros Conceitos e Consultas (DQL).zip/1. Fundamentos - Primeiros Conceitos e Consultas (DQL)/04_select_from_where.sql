SELECT *

FROM produtos

WHERE DescCategoriaProduto = 'rpg'

LIMIT 10