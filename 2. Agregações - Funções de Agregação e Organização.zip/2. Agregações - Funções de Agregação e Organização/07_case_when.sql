-- Intervalos
--0 a 500 → Pônei
--501 a 1000 → Pônei Premium
--1001 a 5000 → Mago Aprendiz
--5001 a 1000 → Mago Mestre
--+10001 → Mago Supremo

SELECT idCliente,
        qtdePontos,
        CASE 
            WHEN QtdePontos <= 500 THEN 'Pônei'
            WHEN QtdePontos > 500 AND QtdePontos <= 1000 THEN 'Pônei Premium'
            WHEN qtdePontos > 1000 AND qtdePontos <= 5000 THEN 'Mago Aprendiz'
            WHEN qtdePontos > 5000 AND qtdePontos <= 10000 THEN 'Mago Mestre'
           ELSE 'Mago Supremo'
                    END AS NomeGrupo,
        
        CASE
        WHEN QtdePontos <= 1000 THEN 1
        ELSE 0
        END AS FLPonei,

        CASE
        WHEN QtdePontos > 1000 THEN 1
        ELSE 0
        END AS FlMago   
 
FROM clientes

WHERE flponei = 1 

ORDER BY QtdePontos DESC


