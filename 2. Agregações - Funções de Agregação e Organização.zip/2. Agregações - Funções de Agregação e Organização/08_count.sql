SELECT count(*)

FROM clientes;


