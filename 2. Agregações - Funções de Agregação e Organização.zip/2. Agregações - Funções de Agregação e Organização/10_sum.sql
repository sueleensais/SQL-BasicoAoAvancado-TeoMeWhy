SELECT 

    SUM (qtdePontos),
        
       
    SUM (CASE
            WHEN QtdePontos > 0 THEN QtdePontos
        END) AS QtdePontosPositivo,

    SUM (CASE
            WHEN QtdePontos < 0 THEN QtdePontos
        END) AS qtdePontosNegativo

FROM transacoes

WHERE DtCriacao >= '2025-07-01'
AND DtCriacao < '2025-08-01'

