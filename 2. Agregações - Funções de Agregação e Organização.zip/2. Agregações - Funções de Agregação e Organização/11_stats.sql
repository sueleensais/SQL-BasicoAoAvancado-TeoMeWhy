SELECT round(avg(qtdePontos),2)
AS MédiaCarteira,

min(qtdePontos)
AS MínimoPontos,

max(qtdePontos)
AS MáximoPontos,

sum(flTwitch)
AS QtdeTwitch,

sum(flEmail)
AS QtdeEmail

FROM clientes

