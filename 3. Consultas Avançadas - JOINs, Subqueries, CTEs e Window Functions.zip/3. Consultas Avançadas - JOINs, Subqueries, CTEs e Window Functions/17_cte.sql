--Dos clientes que começaram SQL no primeiro dia, quantos chegaram ao quinto dia?

WITH tb_clientes_primeiro_dia AS (

    SELECT DISTINCT idCliente
    FROM transacoes
    WHERE substr(DtCriacao,1,10) = '2025-08-25'
),

tb_clientes_ultimo_dia AS (
 SELECT DISTINCT idCliente
    FROM transacoes
    WHERE substr(DtCriacao,1,10) = '2025-08-29'
),

tb_join AS (
    SELECT 
        t1.idCliente AS primeirocliente,
        t2.idCliente AS ultimocliente
    FROM tb_clientes_primeiro_dia AS t1
    LEFT JOIN tb_clientes_ultimo_dia AS t2
    ON t1.idCliente = t2.idCliente
)

SELECT 
    count(primeirocliente),
    count(ultimocliente),
    1. * count(ultimocliente) / count(primeirocliente)

FROM tb_join