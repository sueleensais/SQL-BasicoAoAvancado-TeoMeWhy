--Quantidade de transações acumuladas por pessoa ao longo do tempo?

WITH tb_cliente_dia AS (
    SELECT idCliente,
        substr(DtCriacao,1,10) AS DtDia,
        count(DISTINCT IdTransacao) AS QtdeTransação

    FROM transacoes

    WHERE DtCriacao >= '2025-08-25'
    AND DtCriacao < '2025-08-30'

    GROUP BY idCliente, DtDia
),

tb_leg AS (

SELECT *,
    sum(QtdeTransação) OVER (PARTITION BY idCliente ORDER BY DtDia) AS Acumulado,
    lag(QtdeTransação) OVER (PARTITION BY idCliente ORDER BY DtDia) AS LagTransação

FROM tb_cliente_dia
)

SELECT *,
 1. * QtdeTransação / LagTransação AS PercentualEngajamento

FROM tb_leg
