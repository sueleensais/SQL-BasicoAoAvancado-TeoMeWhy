-- De quanto em quanto tempo as pessoas voltam para assitir TeoMeWhy, em média?

WITH tb_cliente_dia AS (

    SELECT 
        DISTINCT
        idCliente,
        substr(DtCriacao,1,10) AS DtDia

    FROM transacoes

    WHERE substr(DtCriacao,1,4) = '2025'

    ORDER BY idCliente, DtDia
),

tb_lag AS (

    SELECT *,
        lag(DtDia) OVER (PARTITION BY idCliente ORDER BY DtDia) AS LagDia

    FROM tb_cliente_dia
),

tb_diferença_dia AS (

    SELECT *,
        julianday(DtDia) - julianday(LagDia) AS DiferençaDia

    FROM tb_lag
),

avg_cliente AS (

    SELECT idCliente,
        avg(DiferençaDia) AS AvgDia

    FROM tb_diferença_dia

    GROUP BY idCliente
)

SELECT avg(AvgDia)

FROM avg_cliente