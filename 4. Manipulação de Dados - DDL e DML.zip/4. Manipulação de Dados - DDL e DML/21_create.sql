
DROP TABLE IF EXISTS relatorio_diario;

CREATE TABLE IF NOT EXISTS relatorio_diario AS

WITH tb_diario AS (
    SELECT substr(DtCriacao,1,10) AS DtDia,
        count(DISTINCT IdTransacao) AS QtdeTransação

    FROM transacoes

     GROUP BY DtDia
     ORDER BY DtDia
),

tb_acumulada AS (

    SELECT *,
        sum(QtdeTransação) OVER (ORDER BY DtDia) AS QtdeTransaçãoAcumulada

    FROM tb_diario
)

SELECT *
FROM tb_acumulada;

SELECT *
FROM relatorio_diario;