DROP TABLE IF EXISTS clientes_dia28;

CREATE TABLE IF NOT EXISTS clientes_dia28 (
    IdCliente varchar(250) PRIMARY KEY,
    QtdeTransações INTEGER
);

INSERT INTO clientes_dia28
SELECT idCliente,
    count(DISTINCT IdTransacao) AS QtdeTransações

FROM transacoes

WHERE julianday('now') - julianday(substr(DtCriacao,1,10)) <= 28

GROUP BY IdCliente
;

SELECT *

FROM clientes_dia28;