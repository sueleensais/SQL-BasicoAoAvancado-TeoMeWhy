--Quantos clientes tem e-mail cadastrado?

SELECT sum(flEmail) 
    AS QtdEmailCadastrado

FROM clientes;

SELECT count(*)
    AS QtdeEmailCadastrado

FROM clientes

WHERE flEmail = 1;
