--Lista de transações com apenas 1 ponto--
SELECT *

FROM transacoes

WHERE qtdePontos = 1