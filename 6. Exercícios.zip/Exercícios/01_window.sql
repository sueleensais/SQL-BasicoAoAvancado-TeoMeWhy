--Quantidade de Transações Acumuladas ao longo do tempo (diário)

WITH tb_diario AS (
    SELECT substr(DtCriacao,1,10) AS DtDia,
        count(DISTINCT IdTransacao) AS QtdeTransação

    FROM transacoes

     GROUP BY DtDia
     ORDER BY DtDia
),

tb_acumulada AS (

    SELECT *,
        sum(QtdeTransação) OVER (ORDER BY DtDia) AS QtdeTransaçãoAcumulada

    FROM tb_diario
)

SELECT * 

FROM tb_acumulada

WHERE QtdeTransaçãoAcumulada > 100000

ORDER BY QtdeTransaçãoAcumulada

LIMIT 1