--Lista de pedidos realizados no fim de semana--

SELECT IdTransacao, 
         DtCriacao,
         substr(DtCriacao, 1, 10) AS DtCriacaoSubstr,
         datetime(substr(DtCriacao, 1, 10)) AS DtCriacaoNovo,
         strftime('%w', datetime(substr(DtCriacao, 1, 10))) AS DiaSemana


FROM transacoes

WHERE strftime('%w', datetime(substr(DtCriacao, 1, 10))) IN ('6', '0')