-- Quantidade de usuários cadastrados (absoluto e acumulado) ao longo do  tempo?

WITH tb_diacliente AS (

    SELECT
    substr(DtCriacao,1,10) AS DtDia,
    count(DISTINCT idCliente) AS QtdeCliente

    FROM clientes

    GROUP BY DtDia
),

tb_acumulada AS (

    SELECT *,
        sum(QtdeCliente) OVER (ORDER BY DtDia) AS QtdeClienteAcumulada

    FROM tb_diacliente
)

SELECT *

FROM tb_acumulada

WHERE QtdeClienteAcumulada > 3000

ORDER BY QtdeClienteAcumulada
LIMIT 1
