-- Qual o dia da semana mais ativo de cada usuário

WITH tb_cliente_semana AS (

    SELECT idCliente,
            strftime('%w', substr(DtCriacao,1,10)) AS DiaSemana,
            count(DISTINCT IdTransacao) AS QtdeTransação

    FROM transacoes

    GROUP BY idCliente, DiaSemana
),

tb_rn AS (

    SELECT *,
        CASE
        WHEN DiaSemana = '1' THEN 'Segunda-Feira'
        WHEN DiaSemana = '2' THEN 'Terça-Feira'
        WHEN DiaSemana = '3' THEN 'Quarta-Feira'
        WHEN DiaSemana = '4' THEN 'Quinta-Feira'
        WHEN DiaSemana = '5' THEN 'Sexta-Feira'
        WHEN DiaSemana = '6' THEN 'Sábado'
        ELSE 'Domingo'
        END AS DescriçãoDiaSemana,
    

        row_number () OVER (PARTITION BY IdCliente ORDER BY QtdeTransação DESC) AS rn

    FROM tb_cliente_semana
    )

SELECT *
FROM tb_rn
WHERE rn = 1