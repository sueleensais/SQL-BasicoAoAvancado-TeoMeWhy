--Quantos produtos são de rpg?

SELECT 
        count(*)
        AS QtdeRpg

FROM produtos

WHERE DescCategoriaProduto = 'rpg';

SELECT  
        DescCategoriaProduto,
        count(*)

FROM produtos

GROUP BY DescCategoriaProduto;