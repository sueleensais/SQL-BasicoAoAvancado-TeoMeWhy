--Saldo de pontos acumulado de cada usuário.

WITH tb_cliente_transações AS (

    SELECT idCliente,
        substr(DtCriacao,1,10) AS DtDia,
        sum(qtdePontos) AS TotalPontos,
        sum(CASE WHEN qtdePontos > 0 THEN QtdePontos ELSE 0 END) AS PtsPositivos

    FROM transacoes

    GROUP BY idCliente, DtDia
)

SELECT *,
    sum(TotalPontos) OVER (PARTITION BY IdCliente ORDER BY DtDia) AS SaldoPontos,
    sum(PtsPositivos) OVER (PARTITION BY IdCliente ORDER BY DtDia) AS TotalPtsCliente

FROM tb_cliente_transações  