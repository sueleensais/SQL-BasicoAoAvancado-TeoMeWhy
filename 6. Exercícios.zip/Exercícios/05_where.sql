--Lista de produtos com nome que começa com “venda de”--

SELECT *

FROM produtos

WHERE DescNomeProduto LIKE 'venda de%'