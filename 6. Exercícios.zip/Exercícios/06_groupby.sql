--Qual dia da semana tem mais pedidos em 2025?

SELECT 
    strftime('%w', datetime(substr(DtCriacao, 1,10))) AS DiaDaSemana,
    count(*) AS QtdeTransação

FROM transacoes

WHERE DtCriacao >= '2025-01-01'
AND DtCriacao < '2026-01-01'

GROUP BY 1
ORDER BY 2 DESC