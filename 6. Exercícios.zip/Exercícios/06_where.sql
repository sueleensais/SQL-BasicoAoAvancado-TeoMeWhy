--Lista de produtos com nome que termina com “Lover”--

SELECT *

FROM produtos

WHERE DescNomeProduto LIKE '%Lover'