--Qual o produto mais transacionado?

SELECT 
    IdProduto,
    count(*) AS QtdeTransações

FROM transacao_produto

GROUP BY IdProduto

ORDER BY count(*) DESC

LIMIT 1;

SELECT 
    IdProduto,
    sum(QtdeProduto) AS QtdeTransações

FROM transacao_produto

GROUP BY IdProduto
ORDER BY sum(QtdeProduto) DESC

LIMIT 1;

