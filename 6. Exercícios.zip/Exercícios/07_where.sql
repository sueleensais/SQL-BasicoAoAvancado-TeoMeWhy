--Lista de produtos que são “chapéu”--

SELECT *

FROM produtos

WHERE DescNomeProduto LIKE '%chapéu%'