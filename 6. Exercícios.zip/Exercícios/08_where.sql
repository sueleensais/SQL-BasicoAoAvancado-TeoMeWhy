-- Lista de transações com o produto “Resgatar Ponei”--

SELECT *

FROM transacao_produto

WHERE IdProduto = 15